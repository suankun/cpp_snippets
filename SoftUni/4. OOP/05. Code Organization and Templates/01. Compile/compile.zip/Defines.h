#ifndef _DEFINES_H_
#define _DEFINES_H_

#include <iostream>
#include <string>

#define DONT_COMPILE_THIS

#define STANDARD_TEMPLATE_LIBRARY namespace std

#endif // _DEFINES_H_
