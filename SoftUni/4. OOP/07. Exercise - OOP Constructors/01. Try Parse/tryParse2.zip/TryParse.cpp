#include <sstream>

#include "TryParse.h"

bool tryParse(const std::string & str, int & i) {
    std::istringstream istr(str);
    istr >> i;

    return (bool)istr;
}