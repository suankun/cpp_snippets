#ifndef _TRY_PARSE_
#define _TRY_PARSE_

bool tryParse(const std::string & str, int & i);

#endif // _TRY_PARSE_